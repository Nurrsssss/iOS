//
//  FavoriteItem.swift
//  Favorites Manager App
//
//  Created by Nursultan Tolegen on 21.11.2025.
//

import UIKit

/// Base protocol for all favorite items
protocol FavoriteItem {
    var id: String { get }
    var title: String { get }
    var imageName: String { get }
    var description: String { get }
    var review: String { get }
}

/// Model for Movie favorites
struct Movie: FavoriteItem {
    let id: String
    let title: String
    let imageName: String
    let description: String
    let review: String
    let director: String
    let year: Int
}

/// Model for Music favorites
struct Song: FavoriteItem {
    let id: String
    let title: String
    let imageName: String
    let description: String
    let review: String
    let artist: String
    let album: String
    let year: Int
}

/// Model for Book favorites
struct Book: FavoriteItem {
    let id: String
    let title: String
    let imageName: String
    let description: String
    let review: String
    let author: String
    let year: Int
}

/// Model for Course favorites
struct Course: FavoriteItem {
    let id: String
    let title: String
    let imageName: String
    let description: String
    let review: String
    let instructor: String
    let platform: String
    let duration: String
}

