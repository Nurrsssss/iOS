//
//  MoviesViewController.swift
//  Favorites Manager App
//
//  Created by Nursultan Tolegen on 21.11.2025.
//

import UIKit

/// View controller for displaying favorite movies
class MoviesViewController: CategoryViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Movies"
        loadMovies()
    }
    
    private func loadMovies() {
        items = [
            Movie(
                id: "1",
                title: "The Shawshank Redemption",
                imageName: "Unknown-1",
                description: "Two imprisoned men bond over a number of years, finding solace and eventual redemption through acts of common decency. This classic drama directed by Frank Darabont is based on Stephen King's novella and features outstanding performances by Tim Robbins and Morgan Freeman.",
                review: "An absolute masterpiece! The storytelling is impeccable, and the character development is phenomenal. This movie teaches us about hope, friendship, and perseverance. It's a film I can watch over and over again.",
                director: "Frank Darabont",
                year: 1994
            ),
            Movie(
                id: "2",
                title: "Inception",
                imageName: "Unknown-2",
                description: "A skilled thief is given a chance at redemption if he can accomplish the impossible task of inception: planting an idea in someone's mind. Christopher Nolan's mind-bending thriller explores the boundaries of reality and dreams.",
                review: "Brilliant concept and execution! The visual effects are stunning, and the plot keeps you engaged from start to finish. Hans Zimmer's score is phenomenal. A true cinematic experience.",
                director: "Christopher Nolan",
                year: 2010
            ),
            Movie(
                id: "3",
                title: "The Dark Knight",
                imageName: "Unknown-3",
                description: "Batman faces his greatest challenge yet when the Joker wreaks havoc on Gotham City. Heath Ledger's iconic performance and Nolan's direction create one of the greatest superhero films ever made.",
                review: "Heath Ledger's Joker is legendary! The movie perfectly balances action, drama, and psychological depth. The moral dilemmas presented are thought-provoking. A superhero film that transcends the genre.",
                director: "Christopher Nolan",
                year: 2008
            ),
            Movie(
                id: "4",
                title: "Pulp Fiction",
                imageName: "Unknown-4",
                description: "The lives of two mob hitmen, a boxer, a gangster and his wife, and a pair of diner bandits intertwine in four tales of violence and redemption. Quentin Tarantino's non-linear narrative revolutionized cinema.",
                review: "Tarantino at his finest! The dialogue is sharp, the characters are memorable, and the soundtrack is iconic. The non-linear storytelling keeps you engaged throughout. A true classic.",
                director: "Quentin Tarantino",
                year: 1994
            ),
            Movie(
                id: "5",
                title: "The Matrix",
                imageName: "Unknown-5",
                description: "A computer hacker learns about the true nature of reality and his role in the war against its controllers. The Wachowskis' groundbreaking sci-fi film redefined action cinema with its innovative visual effects.",
                review: "Revolutionary filmmaking! The concept of the Matrix is mind-blowing, and the action sequences are iconic. Keanu Reeves is perfect as Neo. This movie changed how we think about reality and technology.",
                director: "The Wachowskis",
                year: 1999
            ),
            Movie(
                id: "6",
                title: "Forrest Gump",
                imageName: "Unknown-6",
                description: "The presidencies of Kennedy and Johnson, the Vietnam War, and other historical events unfold through the perspective of an Alabama man with an IQ of 75. Tom Hanks delivers an unforgettable performance.",
                review: "Heartwarming and inspiring! Tom Hanks brings Forrest to life beautifully. The way the film weaves through American history is masterful. It's a story about love, perseverance, and the simple joys of life.",
                director: "Robert Zemeckis",
                year: 1994
            ),
            Movie(
                id: "7",
                title: "Interstellar",
                imageName: "Unknown-7",
                description: "A team of explorers travel through a wormhole in space in an attempt to ensure humanity's survival. Christopher Nolan's epic combines hard science with emotional storytelling.",
                review: "Visually stunning and emotionally powerful! The science is fascinating, and the father-daughter relationship is heart-wrenching. Hans Zimmer's score elevates every scene. A masterpiece of science fiction.",
                director: "Christopher Nolan",
                year: 2014
            ),
            Movie(
                id: "8",
                title: "The Godfather",
                imageName: "Unknown-8",
                description: "The aging patriarch of an organized crime dynasty transfers control to his reluctant son. Francis Ford Coppola's epic crime saga is considered one of the greatest films ever made.",
                review: "Cinematic perfection! Marlon Brando and Al Pacino deliver career-defining performances. The storytelling is masterful, and the cinematography is beautiful. A true work of art that stands the test of time.",
                director: "Francis Ford Coppola",
                year: 1972
            ),
            Movie(
                id: "9",
                title: "Fight Club",
                imageName: "Unknown",
                description: "An insomniac office worker and a devil-may-care soapmaker form an underground fight club that evolves into something much bigger. David Fincher's dark satire is both shocking and thought-provoking.",
                review: "Mind-bending and provocative! The twist is legendary, and the social commentary is sharp. Brad Pitt and Edward Norton are incredible. This film makes you question consumerism and modern society.",
                director: "David Fincher",
                year: 1999
            ),
            Movie(
                id: "10",
                title: "Parasite",
                imageName: "Unknown-9",
                description: "A poor family schemes to become employed by a wealthy family by infiltrating their household and posing as unrelated, highly qualified individuals. Bong Joon-ho's masterpiece won the Palme d'Or and Best Picture.",
                review: "Brilliant social commentary! The class divide is explored with dark humor and shocking twists. The direction is flawless, and every scene serves a purpose. A perfect blend of thriller, comedy, and drama.",
                director: "Bong Joon-ho",
                year: 2019
            ),
            Movie(
                id: "11",
                title: "Spirited Away",
                imageName: "Unknown-10",
                description: "During her family's move to the suburbs, a sullen 10-year-old girl wanders into a world ruled by gods, witches, and spirits. Hayao Miyazaki's animated masterpiece is a journey of growth and self-discovery.",
                review: "Pure magic! The animation is breathtaking, and the story is enchanting. Chihiro's journey is relatable and inspiring. This film reminds us of the wonder and mystery in the world. A timeless classic.",
                director: "Hayao Miyazaki",
                year: 2001
            ),
            Movie(
                id: "12",
                title: "The Lord of the Rings: The Fellowship of the Ring",
                imageName: "Unknown-11",
                description: "A meek Hobbit from the Shire and eight companions set out on a journey to destroy the powerful One Ring and save Middle-earth from the Dark Lord Sauron. Peter Jackson's epic fantasy adventure.",
                review: "Epic storytelling at its finest! The world-building is incredible, and the characters are unforgettable. The cinematography captures the beauty of New Zealand perfectly. A fantasy epic that sets the standard.",
                director: "Peter Jackson",
                year: 2001
            )
        ]
    }
}

