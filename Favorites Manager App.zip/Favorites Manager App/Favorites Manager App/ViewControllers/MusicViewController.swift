//
//  MusicViewController.swift
//  Favorites Manager App
//
//  Created by Nursultan Tolegen on 21.11.2025.
//

import UIKit

/// View controller for displaying favorite music
class MusicViewController: CategoryViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Music"
        loadSongs()
    }
    
    private func loadSongs() {
        items = [
            Song(
                id: "1",
                title: "Bohemian Rhapsody",
                imageName: "Unknown 1",
                description: "A six-minute suite composed by Freddie Mercury for the band's 1975 album A Night at the Opera. The song is a progressive rock anthem that combines elements of ballad, opera, and hard rock in a unique structure.",
                review: "An absolute masterpiece! The way it transitions between different musical styles is genius. Freddie Mercury's vocal range is incredible. This song never gets old and always gives me chills.",
                artist: "Queen",
                album: "A Night at the Opera",
                year: 1975
            ),
            Song(
                id: "2",
                title: "Stairway to Heaven",
                imageName: "Unknown-1 1",
                description: "A song by the English rock band Led Zeppelin, released in 1971. It's an epic eight-minute track that builds from a gentle acoustic introduction to a powerful rock crescendo, featuring one of the most famous guitar solos in history.",
                review: "The ultimate rock epic! The gradual build-up is masterful, and Jimmy Page's guitar solo is legendary. The lyrics are poetic and mysterious. This song takes you on a journey every time you listen.",
                artist: "Led Zeppelin",
                album: "Led Zeppelin IV",
                year: 1971
            ),
            Song(
                id: "3",
                title: "Hotel California",
                imageName: "Unknown-2 1",
                description: "The title track from the Eagles' 1976 album. The song is known for its iconic guitar solos and cryptic lyrics that have been interpreted in many ways, often seen as a commentary on American excess and the dark side of the California dream.",
                review: "The guitar work is absolutely phenomenal! Don Felder and Joe Walsh's dual guitar solos are mesmerizing. The lyrics are intriguing and open to interpretation. A timeless classic that never fails to captivate.",
                artist: "Eagles",
                album: "Hotel California",
                year: 1976
            ),
            Song(
                id: "4",
                title: "Imagine",
                imageName: "Unknown-3 1",
                description: "A song written and performed by John Lennon from his 1971 album of the same name. It's a peaceful anthem that envisions a world without borders, religions, or possessions, promoting unity and peace.",
                review: "A beautiful and powerful message of peace and unity. John Lennon's simple piano melody and heartfelt vocals make this song timeless. It's a reminder of what we could achieve if we worked together.",
                artist: "John Lennon",
                album: "Imagine",
                year: 1971
            ),
            Song(
                id: "5",
                title: "Billie Jean",
                imageName: "Unknown-4 1",
                description: "A song by Michael Jackson from his 1982 album Thriller. The track features Jackson's signature vocal style and a distinctive bass line. It was one of the first music videos to receive heavy rotation on MTV.",
                review: "Michael Jackson at his absolute best! The bass line is infectious, and his vocal performance is flawless. The music video revolutionized the industry. This song defined an era of pop music.",
                artist: "Michael Jackson",
                album: "Thriller",
                year: 1982
            ),
            Song(
                id: "6",
                title: "Smells Like Teen Spirit",
                imageName: "Unknown-5 1",
                description: "A song by the American rock band Nirvana, released as the lead single from their 1991 album Nevermind. The song is credited with bringing alternative rock to mainstream audiences and defining the grunge movement.",
                review: "The anthem of a generation! Kurt Cobain's raw energy and the explosive chorus are unforgettable. This song captured the angst and frustration of youth perfectly. It changed the music landscape forever.",
                artist: "Nirvana",
                album: "Nevermind",
                year: 1991
            ),
            Song(
                id: "7",
                title: "Like a Rolling Stone",
                imageName: "Unknown-6 1",
                description: "A song by Bob Dylan, released in 1965. At over six minutes, it broke the conventional three-minute pop song format and is considered one of the most influential songs in rock history, featuring Dylan's distinctive vocal style and poetic lyrics.",
                review: "Bob Dylan's masterpiece! The lyrics are poetic and cutting, and the organ work is iconic. This song proved that pop songs could be art. It's a scathing commentary that remains relevant today.",
                artist: "Bob Dylan",
                album: "Highway 61 Revisited",
                year: 1965
            ),
            Song(
                id: "8",
                title: "Purple Rain",
                imageName: "Unknown-7 1",
                description: "A song by Prince and the Revolution from the 1984 album and film of the same name. The epic power ballad features Prince's emotional vocals and an iconic guitar solo, becoming one of his signature songs.",
                review: "Pure emotion and artistry! Prince's guitar solo is legendary, and his vocal performance is heart-wrenching. The song builds to an incredible crescendo. It's a perfect blend of rock, pop, and soul.",
                artist: "Prince",
                album: "Purple Rain",
                year: 1984
            ),
            Song(
                id: "9",
                title: "Sweet Child O' Mine",
                imageName: "Unknown-8 1",
                description: "A song by the American rock band Guns N' Roses, released in 1988. The track features Slash's iconic opening guitar riff and Axl Rose's distinctive vocals, becoming one of the band's most recognizable songs.",
                review: "That opening riff is instantly recognizable! Slash's guitar work is phenomenal, and Axl's vocals are powerful. The song has a perfect balance of hard rock and melodic beauty. A true rock anthem.",
                artist: "Guns N' Roses",
                album: "Appetite for Destruction",
                year: 1988
            ),
            Song(
                id: "10",
                title: "Thunderstruck",
                imageName: "Unknown-9 1",
                description: "A song by the Australian rock band AC/DC, released in 1990. The track is known for its distinctive guitar riff and has become one of the band's most popular songs, often used in sports events and movies.",
                review: "Pure energy and power! The guitar riff is electrifying, and the song builds incredible momentum. It's impossible not to get pumped up when this comes on. AC/DC at their absolute best!",
                artist: "AC/DC",
                album: "The Razors Edge",
                year: 1990
            ),
            Song(
                id: "11",
                title: "Blinding Lights",
                imageName: "Unknown-10 1",
                description: "A song by Canadian singer The Weeknd, released in 2019. The synth-pop track became one of the biggest hits of the 2020s, spending a record-breaking time at the top of the charts and capturing the essence of 80s-inspired pop.",
                review: "Addictive and infectious! The synth melody is catchy, and The Weeknd's vocals are smooth. It perfectly captures that retro 80s vibe while feeling completely modern. A song that gets stuck in your head in the best way.",
                artist: "The Weeknd",
                album: "After Hours",
                year: 2019
            ),
            Song(
                id: "12",
                title: "Shape of You",
                imageName: "Unknown-11 1",
                description: "A song by English singer-songwriter Ed Sheeran, released in 2017. The tropical house-influenced pop song became one of the best-selling digital singles of all time, showcasing Sheeran's ability to create catchy, universal pop music.",
                review: "Incredibly catchy and well-produced! Ed Sheeran's songwriting shines through, and the production is polished. It's a perfect pop song that appeals to a wide audience. The melody is memorable and the rhythm is infectious.",
                artist: "Ed Sheeran",
                album: "÷ (Divide)",
                year: 2017
            )
        ]
    }
}

