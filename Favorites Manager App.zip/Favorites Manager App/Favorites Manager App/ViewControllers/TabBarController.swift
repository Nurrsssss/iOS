//
//  TabBarController.swift
//  Favorites Manager App
//
//  Created by Nursultan Tolegen on 21.11.2025.
//

import UIKit

/// Main tab bar controller managing the four favorite categories
class TabBarController: UITabBarController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTabBar()
    }
    
    // MARK: - Setup
    
    private func setupTabBar() {
        // Create view controllers for each category
        let moviesVC = MoviesViewController()
        let musicVC = MusicViewController()
        let booksVC = BooksViewController()
        let coursesVC = CoursesViewController()
        
        // Embed each in a navigation controller
        let moviesNav = UINavigationController(rootViewController: moviesVC)
        let musicNav = UINavigationController(rootViewController: musicVC)
        let booksNav = UINavigationController(rootViewController: booksVC)
        let coursesNav = UINavigationController(rootViewController: coursesVC)
        
        // Configure tab bar items
        moviesNav.tabBarItem = UITabBarItem(
            title: "Movies",
            image: UIImage(systemName: "film.fill"),
            selectedImage: UIImage(systemName: "film.fill")
        )
        
        musicNav.tabBarItem = UITabBarItem(
            title: "Music",
            image: UIImage(systemName: "music.note"),
            selectedImage: UIImage(systemName: "music.note")
        )
        
        booksNav.tabBarItem = UITabBarItem(
            title: "Books",
            image: UIImage(systemName: "book.fill"),
            selectedImage: UIImage(systemName: "book.fill")
        )
        
        coursesNav.tabBarItem = UITabBarItem(
            title: "Courses",
            image: UIImage(systemName: "laptopcomputer"),
            selectedImage: UIImage(systemName: "laptopcomputer")
        )
        
        // Set view controllers
        viewControllers = [moviesNav, musicNav, booksNav, coursesNav]
        
        // Configure tab bar appearance
        tabBar.tintColor = .systemBlue
        tabBar.unselectedItemTintColor = .systemGray
    }
}

