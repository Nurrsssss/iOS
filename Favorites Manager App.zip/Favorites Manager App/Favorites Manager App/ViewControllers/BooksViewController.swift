//
//  BooksViewController.swift
//  Favorites Manager App
//
//  Created by Nursultan Tolegen on 21.11.2025.
//

import UIKit

/// View controller for displaying favorite books
class BooksViewController: CategoryViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Books"
        loadBooks()
    }
    
    private func loadBooks() {
        items = [
            Book(
                id: "1",
                title: "1984",
                imageName: "Unknown 2",
                description: "A dystopian social science fiction novel by English novelist George Orwell, published in 1949. The novel is set in a totalitarian society where Big Brother watches everything, and independent thought is suppressed. It introduced concepts like Newspeak, thoughtcrime, and the Thought Police.",
                review: "A chilling and prophetic masterpiece! Orwell's vision of totalitarianism is terrifyingly relevant even today. The concept of Big Brother and thought control is brilliantly explored. This book makes you question authority and the nature of truth. Essential reading for everyone.",
                author: "George Orwell",
                year: 1949
            ),
            Book(
                id: "2",
                title: "To Kill a Mockingbird",
                imageName: "Unknown-12",
                description: "A novel by Harper Lee, published in 1960. Set in the American South during the 1930s, the story is told through the eyes of Scout Finch, a young girl whose father, Atticus, defends a Black man falsely accused of rape. The novel addresses themes of racial inequality and moral growth.",
                review: "A powerful and moving story about justice, morality, and growing up. Atticus Finch is one of literature's greatest characters - a true moral compass. The book's message about empathy and understanding is timeless. It's beautifully written and deeply affecting.",
                author: "Harper Lee",
                year: 1960
            ),
            Book(
                id: "3",
                title: "The Great Gatsby",
                imageName: "Unknown-13",
                description: "A novel by American writer F. Scott Fitzgerald, published in 1925. Set in the Jazz Age on prosperous Long Island, the story follows Nick Carraway's interactions with mysterious millionaire Jay Gatsby and Gatsby's obsession with reuniting with his former lover, Daisy Buchanan.",
                review: "Fitzgerald's prose is absolutely beautiful! The symbolism and themes of the American Dream are masterfully woven throughout. Gatsby's tragic pursuit of an unattainable ideal is heartbreaking. The book captures the essence of the Roaring Twenties perfectly.",
                author: "F. Scott Fitzgerald",
                year: 1925
            ),
            Book(
                id: "4",
                title: "Pride and Prejudice",
                imageName: "Unknown-14",
                description: "A romantic novel by Jane Austen, published in 1813. The story follows Elizabeth Bennet as she deals with issues of manners, upbringing, morality, education, and marriage in the society of the landed gentry of the British Regency. It's one of the most popular novels in English literature.",
                review: "A delightful and witty romance! Elizabeth Bennet is a fantastic protagonist - intelligent, independent, and sharp-tongued. Austen's social commentary is brilliant, and the dialogue is sparkling. Mr. Darcy's character development is wonderful. A true classic that never gets old.",
                author: "Jane Austen",
                year: 1813
            ),
            Book(
                id: "5",
                title: "The Catcher in the Rye",
                imageName: "Unknown-15",
                description: "A novel by J.D. Salinger, published in 1951. The story is told by Holden Caulfield, a teenager who has been expelled from prep school, as he wanders around New York City. The novel deals with themes of alienation, loss of innocence, and the phoniness of the adult world.",
                review: "Holden's voice is authentic and unforgettable! The book perfectly captures teenage angst and disillusionment. Salinger's writing style is unique and engaging. It's a coming-of-age story that resonates with anyone who's felt like an outsider. Controversial but brilliant.",
                author: "J.D. Salinger",
                year: 1951
            ),
            Book(
                id: "6",
                title: "Lord of the Flies",
                imageName: "Unknown-16",
                description: "A novel by William Golding, published in 1954. The story follows a group of British boys stranded on an uninhabited island and their disastrous attempt to govern themselves. The novel explores the conflict between civilization and savagery, and the inherent evil in human nature.",
                review: "A dark and thought-provoking allegory! Golding's exploration of human nature is chilling. The descent into savagery is masterfully depicted. The book raises important questions about society, morality, and the thin line between civilization and chaos. Disturbing but essential reading.",
                author: "William Golding",
                year: 1954
            ),
            Book(
                id: "7",
                title: "The Hobbit",
                imageName: "Unknown-17",
                description: "A fantasy novel by J.R.R. Tolkien, published in 1937. The story follows Bilbo Baggins, a hobbit who is swept into an epic quest to reclaim a lost kingdom from the dragon Smaug. The novel serves as a prelude to The Lord of the Rings trilogy.",
                review: "A delightful adventure story! Bilbo's journey from a comfortable hobbit to a brave adventurer is wonderful. Tolkien's world-building is incredible, and the characters are memorable. The book has a perfect balance of humor, adventure, and heart. A timeless fantasy classic.",
                author: "J.R.R. Tolkien",
                year: 1937
            ),
            Book(
                id: "8",
                title: "Brave New World",
                imageName: "Unknown-18",
                description: "A dystopian novel by Aldous Huxley, published in 1932. Set in a futuristic World State where humans are genetically bred and pharmaceutically conditioned to be passive, the novel explores themes of technology, happiness, and the cost of utopia.",
                review: "A fascinating and disturbing vision of the future! Huxley's predictions about technology and society are eerily prescient. The contrast between happiness and freedom is thought-provoking. The book makes you question what we're willing to sacrifice for comfort and stability.",
                author: "Aldous Huxley",
                year: 1932
            ),
            Book(
                id: "9",
                title: "The Kite Runner",
                imageName: "Unknown-19",
                description: "A novel by Khaled Hosseini, published in 2003. The story follows Amir, a young boy from Kabul, and his journey of redemption. Set against the backdrop of Afghanistan's tumultuous history, the novel explores themes of friendship, betrayal, guilt, and redemption.",
                review: "Emotionally powerful and beautifully written! The story of Amir and Hassan is heartbreaking. Hosseini's portrayal of Afghanistan is vivid and moving. The themes of guilt and redemption are masterfully explored. This book will stay with you long after you finish it.",
                author: "Khaled Hosseini",
                year: 2003
            ),
            Book(
                id: "10",
                title: "The Alchemist",
                imageName: "Unknown-20",
                description: "A novel by Brazilian author Paulo Coelho, published in 1988. The story follows Santiago, a young Andalusian shepherd, on his journey to find a treasure in the Egyptian pyramids. The novel is a philosophical tale about following one's dreams and finding one's personal legend.",
                review: "An inspiring and philosophical journey! Coelho's simple yet profound storytelling is beautiful. The book's message about following your dreams and listening to your heart is timeless. It's a quick read but leaves a lasting impact. Perfect for anyone seeking inspiration.",
                author: "Paulo Coelho",
                year: 1988
            ),
            Book(
                id: "11",
                title: "Sapiens",
                imageName: "Unknown-1 2",
                description: "A book by Yuval Noah Harari, published in 2011. The book surveys the history of humankind from the evolution of archaic human species in the Stone Age up to the twenty-first century, focusing on how Homo sapiens came to dominate the world.",
                review: "Fascinating and thought-provoking! Harari's ability to synthesize vast amounts of history and science is impressive. The book challenges how we think about human history and our place in the world. It's accessible yet profound. A must-read for understanding humanity.",
                author: "Yuval Noah Harari",
                year: 2011
            ),
            Book(
                id: "12",
                title: "The Seven Husbands of Evelyn Hugo",
                imageName: "Unknown-21",
                description: "A novel by Taylor Jenkins Reid, published in 2017. The story follows aging Hollywood icon Evelyn Hugo as she finally decides to tell her life story to an unknown journalist. The novel explores themes of ambition, love, identity, and the price of fame.",
                review: "Absolutely captivating! The storytelling is masterful, and Evelyn Hugo is a complex, fascinating character. The plot twists are surprising, and the emotional depth is incredible. It's a page-turner that also makes you think about love, ambition, and authenticity. Highly recommend!",
                author: "Taylor Jenkins Reid",
                year: 2017
            )
        ]
    }
}

