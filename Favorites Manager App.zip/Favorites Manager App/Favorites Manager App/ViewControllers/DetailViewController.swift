//
//  DetailViewController.swift
//  Favorites Manager App
//
//  Created by Nursultan Tolegen on 21.11.2025.
//

import UIKit

/// Detail view controller displaying full information about a favorite item
class DetailViewController: UIViewController {
    
    // MARK: - Properties
    
    var favoriteItem: FavoriteItem?
    
    // MARK: - UI Components
    
    private let scrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.showsVerticalScrollIndicator = true
        return scrollView
    }()
    
    private let contentView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private let itemImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.backgroundColor = .systemGray5
        imageView.layer.cornerRadius = 12
        return imageView
    }()
    
    private let titleLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 28, weight: .bold)
        label.textColor = .label
        label.numberOfLines = 0
        return label
    }()
    
    private let descriptionLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 17)
        label.textColor = .secondaryLabel
        label.numberOfLines = 0
        return label
    }()
    
    private let reviewSectionLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 22, weight: .semibold)
        label.textColor = .label
        label.text = "Your Review"
        return label
    }()
    
    private let reviewLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 16)
        label.textColor = .label
        label.numberOfLines = 0
        return label
    }()
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        configureWithItem()
    }
    
    // MARK: - Setup
    
    private func setupUI() {
        view.backgroundColor = .systemBackground
        title = "Details"
        
        view.addSubview(scrollView)
        scrollView.addSubview(contentView)
        
        contentView.addSubview(itemImageView)
        contentView.addSubview(titleLabel)
        contentView.addSubview(descriptionLabel)
        contentView.addSubview(reviewSectionLabel)
        contentView.addSubview(reviewLabel)
        
        NSLayoutConstraint.activate([
            // ScrollView constraints
            scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            
            // ContentView constraints
            contentView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            contentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            contentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            contentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            contentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor),
            
            // Image constraints (16:9 aspect ratio)
            itemImageView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 20),
            itemImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            itemImageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            itemImageView.heightAnchor.constraint(equalTo: itemImageView.widthAnchor, multiplier: 9.0/16.0),
            
            // Title constraints
            titleLabel.topAnchor.constraint(equalTo: itemImageView.bottomAnchor, constant: 20),
            titleLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            titleLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            
            // Description constraints
            descriptionLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 16),
            descriptionLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            descriptionLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            
            // Review section label constraints
            reviewSectionLabel.topAnchor.constraint(equalTo: descriptionLabel.bottomAnchor, constant: 24),
            reviewSectionLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            reviewSectionLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            
            // Review label constraints
            reviewLabel.topAnchor.constraint(equalTo: reviewSectionLabel.bottomAnchor, constant: 12),
            reviewLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            reviewLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            reviewLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -20)
        ])
    }
    
    // MARK: - Configuration
    
    private func configureWithItem() {
        guard let item = favoriteItem else { return }
        
        // Try to load from asset catalog first
        if let assetImage = UIImage(named: item.imageName) {
            itemImageView.image = assetImage
            itemImageView.tintColor = nil // Remove tint for regular images
        } else if let systemImage = UIImage(systemName: item.imageName) {
            // Fallback to SF Symbols
            itemImageView.image = systemImage
            itemImageView.tintColor = .systemBlue
        } else {
            // Final fallback to a placeholder
            itemImageView.image = UIImage(systemName: "photo")
            itemImageView.tintColor = .systemGray
        }
        
        titleLabel.text = item.title
        descriptionLabel.text = item.description
        reviewLabel.text = item.review
    }
}

