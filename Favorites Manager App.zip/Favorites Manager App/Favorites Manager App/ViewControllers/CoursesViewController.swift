//
//  CoursesViewController.swift
//  Favorites Manager App
//
//  Created by Nursultan Tolegen on 21.11.2025.
//

import UIKit

/// View controller for displaying favorite courses
class CoursesViewController: CategoryViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Courses"
        loadCourses()
    }
    
    private func loadCourses() {
        items = [
            Course(
                id: "1",
                title: "iOS Development with Swift",
                imageName: "Unknown-22",
                description: "A comprehensive course covering iOS app development from basics to advanced topics. Learn Swift programming, UIKit, SwiftUI, Core Data, networking, and app architecture. Build real-world applications and publish them to the App Store. Perfect for beginners and intermediate developers looking to master iOS development.",
                review: "Excellent course! The instructor explains complex concepts clearly, and the hands-on projects are practical and engaging. I've built several apps using the techniques learned here. The community support is fantastic, and the course materials are well-organized. Highly recommended for anyone serious about iOS development.",
                instructor: "Dr. Sarah Johnson",
                platform: "Coursera",
                duration: "12 weeks"
            ),
            Course(
                id: "2",
                title: "Machine Learning Specialization",
                imageName: "Unknown-2 2",
                description: "A deep dive into machine learning algorithms, neural networks, and deep learning. Cover topics including supervised and unsupervised learning, reinforcement learning, natural language processing, and computer vision. Includes hands-on projects using TensorFlow and PyTorch. Taught by leading experts in the field.",
                review: "Outstanding content! The mathematical foundations are explained thoroughly, and the practical applications are cutting-edge. The assignments are challenging but rewarding. This course gave me a solid understanding of ML that I use daily in my work. Worth every minute!",
                instructor: "Prof. Andrew Ng",
                platform: "Coursera",
                duration: "16 weeks"
            ),
            Course(
                id: "3",
                title: "Full Stack Web Development",
                imageName: "Unknown-3 2",
                description: "Master both front-end and back-end development. Learn HTML, CSS, JavaScript, React, Node.js, databases, and deployment. Build complete web applications from scratch. Covers modern frameworks, RESTful APIs, authentication, and best practices. Perfect for career changers and aspiring developers.",
                review: "Comprehensive and well-structured! The course takes you from zero to building full-stack applications. The projects are real-world relevant, and the instructor's teaching style is engaging. I landed my first developer job after completing this course. The best investment in my career!",
                instructor: "Colt Steele",
                platform: "Udemy",
                duration: "60 hours"
            ),
            Course(
                id: "4",
                title: "Data Structures and Algorithms",
                imageName: "1581342345742",
                description: "Master fundamental computer science concepts. Learn arrays, linked lists, stacks, queues, trees, graphs, and hash tables. Study sorting and searching algorithms, dynamic programming, and complexity analysis. Essential for technical interviews and building efficient software. Includes coding challenges and practice problems.",
                review: "Essential for any serious programmer! The explanations are clear, and the visualizations help understand complex concepts. The practice problems are excellent preparation for technical interviews. This course significantly improved my problem-solving skills and coding efficiency.",
                instructor: "Dr. Robert Sedgewick",
                platform: "Princeton (Coursera)",
                duration: "10 weeks"
            ),
            Course(
                id: "5",
                title: "UI/UX Design Masterclass",
                imageName: "Unknown-23",
                description: "Learn user interface and user experience design principles. Master design tools like Figma and Adobe XD. Understand user research, wireframing, prototyping, and usability testing. Create beautiful, functional designs that users love. Includes portfolio projects and industry best practices.",
                review: "Transformative course! The design principles are explained clearly, and the hands-on projects help you build a strong portfolio. The instructor provides excellent feedback, and the community is supportive. I've applied these skills to multiple projects with great results. Highly recommend!",
                instructor: "Sarah Doody",
                platform: "Skillshare",
                duration: "8 weeks"
            ),
            Course(
                id: "6",
                title: "Unknown-24",
                imageName: "chart.line.uptrend.xyaxis",
                description: "Learn Python programming specifically for data analysis and visualization. Master pandas, NumPy, Matplotlib, and Seaborn. Work with real datasets, perform statistical analysis, and create compelling visualizations. Perfect for analysts, researchers, and aspiring data scientists.",
                review: "Perfect introduction to data science! The Python libraries are explained well, and working with real datasets makes it practical. The visualization techniques are beautiful and informative. This course gave me the skills to analyze data effectively in my research work.",
                instructor: "Dr. Jose Portilla",
                platform: "Udemy",
                duration: "25 hours"
            ),
            Course(
                id: "7",
                title: "Blockchain Development",
                imageName: "Unknown-25",
                description: "Learn blockchain fundamentals, smart contracts, and decentralized applications (DApps). Master Solidity programming, Ethereum development, and Web3 technologies. Build your own blockchain projects and understand cryptocurrency mechanics. Covers security best practices and real-world applications.",
                review: "Cutting-edge content! The blockchain concepts are explained clearly, and building smart contracts is fascinating. The instructor stays current with the latest developments in the space. This course opened up new career opportunities for me in the Web3 space.",
                instructor: "Stephen Grider",
                platform: "Udemy",
                duration: "40 hours"
            ),
            Course(
                id: "8",
                title: "DevOps Engineering",
                imageName: "Unknown-4 2",
                description: "Master DevOps practices and tools. Learn Docker, Kubernetes, CI/CD pipelines, cloud platforms (AWS, Azure, GCP), infrastructure as code, and monitoring. Automate deployments and scale applications efficiently. Essential for modern software development workflows.",
                review: "Comprehensive DevOps training! The hands-on labs are excellent, and you get real experience with industry-standard tools. The course covers everything from basics to advanced topics. My deployment processes improved dramatically after taking this course.",
                instructor: "Mumshad Mannambeth",
                platform: "KodeKloud",
                duration: "50 hours"
            ),
            Course(
                id: "9",
                title: "React Native Mobile Development",
                imageName: "Unknown-5 2",
                description: "Build cross-platform mobile apps with React Native. Learn to create iOS and Android apps using JavaScript and React. Master navigation, state management, APIs, and native modules. Deploy apps to both App Store and Google Play Store.",
                review: "Great for web developers wanting to build mobile apps! React Native is powerful, and this course teaches it well. The projects are practical, and you can build real apps quickly. The instructor explains the differences between platforms clearly. Highly effective!",
                instructor: "Maximilian Schwarzmüller",
                platform: "Udemy",
                duration: "45 hours"
            ),
            Course(
                id: "10",
                title: "Cybersecurity Fundamentals",
                imageName: "Unknown-26",
                description: "Learn essential cybersecurity concepts and practices. Cover network security, cryptography, ethical hacking, penetration testing, and security best practices. Understand common vulnerabilities and how to protect systems. Includes hands-on labs and real-world scenarios.",
                review: "Eye-opening course! The security concepts are crucial for any developer. The labs are engaging, and you learn by doing. Understanding vulnerabilities helps me write more secure code. This course should be required for all software developers.",
                instructor: "Dr. Charles Severance",
                platform: "edX",
                duration: "14 weeks"
            ),
            Course(
                id: "11",
                title: "Advanced JavaScript",
                imageName: "Unknown-6 2",
                description: "Deep dive into advanced JavaScript concepts. Master closures, prototypes, async/await, promises, design patterns, and modern ES6+ features. Learn to write clean, efficient, and maintainable JavaScript code. Perfect for developers looking to master the language.",
                review: "Takes your JavaScript skills to the next level! The advanced concepts are explained clearly with great examples. Understanding closures and prototypes deeply improved my code quality. The design patterns section is particularly valuable. Excellent course!",
                instructor: "Anthony Alicea",
                platform: "Udemy",
                duration: "30 hours"
            ),
            Course(
                id: "12",
                title: "Cloud Architecture with AWS",
                imageName: "images",
                description: "Master Amazon Web Services and cloud architecture. Learn EC2, S3, Lambda, RDS, VPC, and more. Design scalable, secure, and cost-effective cloud solutions. Prepare for AWS certifications. Includes hands-on projects and real-world scenarios.",
                review: "Comprehensive AWS training! The course covers all major services, and the hands-on labs are excellent. I passed my AWS certification after completing this course. The instructor explains complex concepts clearly, and the real-world examples are valuable.",
                instructor: "Ryan Kroonenburg",
                platform: "A Cloud Guru",
                duration: "60 hours"
            )
        ]
    }
}

