# Favorites Manager App

A UIKit-based iOS application for managing user favorites across four categories: Movies, Music, Books, and Courses.

## Features

- **Tab Bar Interface**: Four tabs for different favorite categories
  - 🎬 Movies
  - 🎵 Music
  - 📚 Books
  - 🎓 Courses

- **Table Views**: Each category displays favorites in a table view with:
  - Thumbnail images (60x60 points)
  - Item titles
  - Custom cell design with proper Auto Layout

- **Detail Views**: Tap any item to see:
  - Large image (16:9 aspect ratio)
  - Bold title (28pt)
  - Detailed description (multi-line, scrollable)
  - Personal review section

- **Navigation**: Each tab has its own navigation controller for seamless navigation

## Requirements

- iOS 15.0 or later
- Xcode 15.4 or later
- Swift 5.0

## Project Structure

```
Favorites Manager App/
├── Models/
│   └── FavoriteItem.swift          # Protocol and model structs
├── Views/
│   └── FavoriteTableViewCell.swift  # Custom table view cell
├── ViewControllers/
│   ├── CategoryViewController.swift # Base class for category VCs
│   ├── DetailViewController.swift   # Detail view controller
│   ├── MoviesViewController.swift   # Movies category
│   ├── MusicViewController.swift    # Music category
│   ├── BooksViewController.swift    # Books category
│   ├── CoursesViewController.swift  # Courses category
│   └── TabBarController.swift       # Main tab bar controller
├── AppDelegate.swift
├── SceneDelegate.swift
└── ViewController.swift
```

## How to Run

1. Open `Favorites Manager App.xcodeproj` in Xcode
2. Select a simulator (iPhone SE, iPhone 15 Pro Max, etc.)
3. Press `Cmd + R` to build and run

## Data

Each category contains 12 sample items with:
- Unique titles
- Descriptions (3-4 sentences minimum)
- Personal reviews
- Category-specific metadata (director, artist, author, instructor, etc.)

## Technical Implementation

- **Architecture**: MVC pattern with clear separation of concerns
- **UI**: Programmatic Auto Layout (no Storyboard dependencies for main UI)
- **Navigation**: UINavigationController embedded in each tab
- **Constraints**: All Auto Layout constraints properly configured with no warnings
- **Code Quality**: Well-commented, organized, and follows Swift naming conventions

## Design

- Uses system colors and SF Symbols for icons
- Consistent spacing and padding (16-20pt margins)
- Professional, clean appearance
- Responsive layout that works on all iPhone screen sizes

## Notes

- The app uses programmatic UI setup in `SceneDelegate.swift`
- Images use SF Symbols as placeholders (can be replaced with actual images)
- All constraints are validated and working correctly
- The project builds without errors or warnings

## Future Enhancements (Optional)

- Search functionality
- Mark items as watched/read/completed
- Star rating system
- Swipe actions for deletion
- Empty state views
- Custom transition animations

---

**Built with UIKit and Swift** 🚀

